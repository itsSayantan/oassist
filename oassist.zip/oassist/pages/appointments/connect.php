<?php

$hName = "localhost";
$uName = "root";
$pass = "";
$dbName = "oassist";

$conn = mysqli_connect($hName, $uName, $pass, $dbName) or die('Could not connect');

?>